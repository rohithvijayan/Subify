from django.contrib import admin
from .models import upload_video
# Register your models here.
admin.site.register(upload_video)